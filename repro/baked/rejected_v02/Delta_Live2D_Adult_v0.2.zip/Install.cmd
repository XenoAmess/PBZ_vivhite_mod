@echo off
py -3 "%~dp0install_delta.py"
pause
