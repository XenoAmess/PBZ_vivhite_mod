﻿Delta Live2D 成年魂替换 v0.2

角色只来自 Delta.zip；full.jpg 属于另一份独立模型，没有混用。
少年魂不替换。支持普通成年魂和「传承」外观；同时包含成年Climax身体。
在本机 Steam build 26367565 检查了读档、颜色、待机、移动、挥刀和当前武器挂接。
具体场景、外观和未测范围见 runtime_review.json；Proof 内是本包的实机证据。
这不代表已获用户外观认可，也不代表完整流程、全部武器、其他解锁外观和过场均已验证。

本机已有安装；迁移或重新安装时：关闭游戏后双击 Install.cmd（需要 Python 3）。
卸载：关闭游戏后双击 Uninstall.cmd。脚本只操作三个哈希匹配的本Mod文件。
默认游戏目录：Z:\SteamLibrary\steamapps\common\PBZ

手动安装：将 z_DeltaLive2D_P.pak / .utoc / .ucas 三个文件放入
游戏目录\ProjectPBZ\Content\Paks\~mods。
手动卸载：关闭游戏，只移除上述三个 z_DeltaLive2D_P 文件。

手臂已修正肘锚点、外套误绑、锁骨与袖子权重，并重建五指。
背面为推断设计；腕部是重叠接缝，极端姿态的肩肘领口仍可能挤压。
没有新增脸部表情或衣发物理。原游戏程序和原资源包没有被改写。
