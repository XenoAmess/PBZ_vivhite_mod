Delta.zip Live2D reconstruction only. Inferred rear design.
264 adult Soul bones; 25,609 vertices / 51,084 triangles.
Blender contains packed textures. This archive is editable model data; install the separate Mod archive in the game.
No new facial animation or cloth/hair physics.
